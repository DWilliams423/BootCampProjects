function hide(element) {
    element.remove();
}

function addLike(element) {
    let total = element.nextElementSibling.innerText
    total++
    element.nextElementSibling.innerText = total
}

function search(event) {
    event.preventDefault()
    let query = document.getElementById("searchDessert").value
    alert(`You are searching for ${query}`)
}

function over(element) {
    element.style.backgroundColor = "orange"
}

function out(element) {
    element.style.backgroundColor = ""
}